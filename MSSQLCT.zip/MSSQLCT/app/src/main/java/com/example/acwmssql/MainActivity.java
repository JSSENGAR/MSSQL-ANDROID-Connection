package com.example.acwmssql;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.TextView;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MainActivity extends AppCompatActivity {
    private TextView textView;
    private static  String ip="192.168.1.45";
    private static  String Classes="net.sourceforge.jtds.jdbc.Driver";
    private static  String database= "DB";
    private static  String username="SA";
    private static  String password="@123@";
    private static  String url= "jdbc:jtds:sqlserver://"+ip+"/"+database;
    private Connection connection =null;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.INTERNET}, PackageManager.PERMISSION_GRANTED);

        textView = findViewById(R.id.textView);
        StrictMode.ThreadPolicy policy =new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        try {
            Class.forName(Classes);
            connection = DriverManager.getConnection(url,username,password);
            textView.setText("DB CONNECTED");
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            textView.setText("ERROR/FAILURE");
        }


    }


    public void button(View view) throws SQLException {
        if(connection!=null )
        {

            Statement statement=null;
            statement = connection.createStatement();

            ResultSet resultSet = statement.executeQuery("select * from Login;" );

            while(resultSet.next())
            {
                textView.setText(resultSet.getString(1) );
            }

        }
        else
        {
            textView.setText("Connection is null");
        }

    }
}
